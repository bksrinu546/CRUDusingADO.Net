﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataService;
namespace DataSaveADO.NET.Controllers
{
    public class ProductController : Controller
    {
        private ProductOperations prodOperations;
        public ProductController(ProductOperations _prodOperations)
        {
            prodOperations = _prodOperations;
        }
        // GET: ProductController
        public ActionResult Index()
        {
            List<Product> prods = new List<Product>();
            prods = prodOperations.GetAllProducts();
            return View(prods);
        }

        
        // GET: ProductController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        public IActionResult Create(Product product)
        {
            prodOperations.InsertOrUpdateProduct(product, 0);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetAllProducts();
            return RedirectToAction("Index");
        }

        // GET: ProductController/Edit/5
        public ActionResult Edit(int id)
        {
            Product prod = prodOperations.GetProduct(id);
            return View(prod);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        public IActionResult Edit(Product product)
        {
            prodOperations.InsertOrUpdateProduct(product, 1);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetAllProducts();
            return RedirectToAction("Index");
        }

        // GET: ProductController/Delete/5
        public ActionResult Delete(int id)
        {
            prodOperations.DeleteProduct(id);
            List<Product> lstprods = new List<Product>();
            lstprods = prodOperations.GetAllProducts();
            return RedirectToAction("Index");
        }
        
    }
}
