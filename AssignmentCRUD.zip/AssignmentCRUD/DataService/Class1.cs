﻿using System;

namespace DataService
{
    public class Class1
    {
    }
}
