﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace DataService
{
    public class ProductOperations
    {
        public string ConnectionString { get; set; }
        public ProductOperations(string _connectionString)
        {
            ConnectionString = _connectionString;
        }
        public Product GetProduct(int id)
        {       
            Product prod = new Product();
            SqlConnection dbConn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Products where ProductId=" + id);
            cmd.Connection = dbConn;
            dbConn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dbConn.Close();
            foreach (DataRow dr in dt.Rows)
            {
                prod.ProductId = Convert.ToInt32(dr["ProductId"]);
                prod.Name = Convert.ToString(dr["Name"]);
                prod.Description = Convert.ToString(dr["Description"]);
                prod.UnitPrice = Convert.ToDecimal(dr["UnitPrice"]);                
            }
            return prod;

        }

        public List<Product> GetAllProducts()
        {
            List<Product> lstProds = new List<Product>();
            Product prod;
            SqlConnection dbConn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Products");
            cmd.Connection = dbConn;
            dbConn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dbConn.Close();
            foreach (DataRow dr in dt.Rows)
            {

                lstProds.Add(

                    new Product
                    {

                        ProductId = Convert.ToInt32(dr["ProductId"]),
                        Name = Convert.ToString(dr["Name"]),
                        Description = Convert.ToString(dr["Description"]),
                        UnitPrice = Convert.ToDecimal(dr["UnitPrice"])

                    }
                    );
            }
            return lstProds;

        }

        public void InsertOrUpdateProduct(Product prod, int type)
        {

            SqlConnection dbConn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("InsertProduct");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ProductID", prod.ProductId);
            cmd.Parameters.AddWithValue("@Name", prod.Name);
            cmd.Parameters.AddWithValue("@Description", prod.Description);
            cmd.Parameters.AddWithValue("@UnitPrice", prod.UnitPrice);
            cmd.Parameters.AddWithValue("@Type", type);
            cmd.Connection = dbConn;
            dbConn.Open();
            cmd.ExecuteNonQuery();
            dbConn.Close();
            

        }
        public void DeleteProduct(int id)
        {
            SqlConnection dbConn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Delete from Products where ProductId=" + id);           
            cmd.Connection = dbConn;
            dbConn.Open();
            cmd.ExecuteNonQuery();
            dbConn.Close();

        }
    }
}
